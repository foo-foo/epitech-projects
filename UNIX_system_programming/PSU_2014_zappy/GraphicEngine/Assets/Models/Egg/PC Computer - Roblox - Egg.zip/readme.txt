ROBLOX Egg
Ripped by HellFire2345 / Miles56 

Note: This package only contains the textures from the original set of eggs, nothing afterwards.
If you want the other egg textures, you can download them from the website.